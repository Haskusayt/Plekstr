import os
import lcmds as l
def login():
	l.clear()
	print('Plekstr os started')
	pas=open('user/pass.txt')
	name=open('user/name.txt', 'r')
	epas = input('Type your password ' + name.	read() + ':  ')
	if epas == pas.read():
		l.clear()
		start()
	else:
		print('Incorrect password')
		login()

def start():
	program = input('What program does you want to run(Your program,cmd)?    ')
	if program == 'Your program':
		print('Coming soon')
	if program == "cmd":
	    import cmd
	else:
	 	print('Incorrect program')
	 	start()
