ir = open('user/installed.txt', 'r')
i = ir.read()
nr = open('user/name.txt', 'r')
n = nr.read()
pr = open('user/pass.txt', 'r')
p = pr.read()

iw = open('user/installed.txt', 'w')
iw.writelines(['1'])
iw.close()
nw = open('user/name.txt', 'w')
name = input('Input your name.  ')
nw.writelines([name])
def pas():
	pw = open('user/pass.txt', 'w')
	pas1 = input('Input your password.  ')
	pas2 = input('Type your password to rember it  ')
	if pas1 == pas2:
		pw.writelines([pas1])
		import system
		system.login()
	else:
		import lcmds
		lcmds.clear()
		pas()
pas()