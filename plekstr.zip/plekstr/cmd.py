ex = '1'
import os
os.system('clear')
while ex=='1':
	cmd = input('>>>  ')
	if cmd == 'help':
		print('Close program - quit\n')
			
	if cmd == 'quit':
		import system
		system.start()
		
	else:
		os.system(cmd)
	