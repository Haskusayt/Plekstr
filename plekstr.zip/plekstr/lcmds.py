def exc(cmd):
	import os
	os.system(cmd)
def clear():
	import os
	os.system('clear')